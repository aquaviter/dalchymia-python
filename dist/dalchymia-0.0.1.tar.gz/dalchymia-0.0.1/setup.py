#!/usr/bin/env python
# _*_ coding: utf-8 _*_

from distutils.core import setup

setup(
    name = 'dalchymia',
    version = '0.0.1',
    packages = [ 'dalchymia', ],
    license = '　Released under the MIT license',
    long_description = open('README.rst').read()
)
